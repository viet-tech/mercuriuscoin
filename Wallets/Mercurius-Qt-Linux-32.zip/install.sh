echo "installing Mercurius Coin"
cp Mercurius-Qt /usr/sbin
cp Mercurius-Qt.desktop /usr/share/applications
cp mercurius.png /usr/share/icons
chmod +x /usr/sbin/Mercurius-Qt
chmod +x /usr/share/applications/Mercurius-Qt.desktop
chmod +x /usr/share/icons/mercurius.png
echo "done"
